package com.objectClassesConstructor;

//Creating a class
public class Dog {
	   String breed;
	   int age;
	   String color;

	   void barking() {
	   }

	   void hungry() {
	   }

	   void sleeping() {
	   }}
