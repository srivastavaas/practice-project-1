package com.objectClassesConstructor;


public class constructor {
	   public constructor() {
	   }

	   public constructor(String name) {
	      // This constructor has one parameter, name.
	   }}
