
public class AccessModifiers {
	// Public field
    public String publicField = "Public Field";

    // Protected field
    protected String protectedField = "Protected Field";

    // Default (package-private) field
    String defaultField = "Default Field";

    // Private field
    private String privateField = "Private Field";

    // Public constructor
    public AccessModifiers() {
        System.out.println("Public Constructor");
    }

    // Protected method
    protected void protectedMethod() {
        System.out.println("Protected Method");
    }

    // Default (package-private) method
    void defaultMethod() {
        System.out.println("Default Method");
    }

    // Private method
    private void privateMethod() {
        System.out.println("Private Method");
    }

    // Main method
    public static void main(String[] args) {
        AccessModifiers example = new AccessModifiers();

        // Accessing fields
        System.out.println("Public Field: " + example.publicField);
        System.out.println("Protected Field: " + example.protectedField);
        System.out.println("Default Field: " + example.defaultField);
        System.out.println("Private Field: " + example.privateField); // This will cause a compilation error

        // Accessing methods
        example.protectedMethod();
        example.defaultMethod();
        example.privateMethod(); // This will cause a compilation error
    }

}
