
public class SingleLevelInheritance {

}
